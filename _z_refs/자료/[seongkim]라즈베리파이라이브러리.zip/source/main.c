
#include "main.h"

// 프로그램 진입점
int main()
{
    int hdev; // RFID 리더 디바이스 핸들

    // USB RFID 리더 초기화
    hdev = usbRFIDreader_init();
    if (hdev == -1)
    {
        // 초기화 실패 시 메시지 출력 후 종료
        printf("Failed to initialize USB RFID reader\n");
        return -1;
    }

    // 카드 감지 수행
    // 현재 무한 루프로 동작함
    // 이후 별도의 스레드로 분리 및 관리
    detectCards(hdev);

    // 정상 종료
    return 0;
}