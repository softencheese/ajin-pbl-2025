#include "main.h"

// USB RFID 리더기를 초기화하는 함수
int usbRFIDreader_init()
{
    char            device_path[64];    // 장치 경로를 저장할 문자열 배열
    unsigned char   szVer[128];         // 버전 정보를 저장할 배열
    int             hdev;               // 장치 핸들
    int             device_num = 0;     // 장치 번호

    do
    {
        // hiddev 장치 경로 생성
        sprintf(device_path, "/dev/usb/hiddev%d", device_num);
        // 지정된 경로와 BAUDRATE로 장치 초기화 시도
        if( (hdev = lc_init_ex(2, device_path, BAUDRATE)) == -1 )
       {
            // 장치 열기 시도 메시지 출력
            printf("Try to open %s\n", device_path);
            // 초기화 오류 메시지 출력
            printf("lc_init_ex ERR %d\n", hdev);
            return -1; // 오류 반환
        }

        // 장치에서 버전 정보 가져오기
        if (lc_getver(hdev, szVer) == 0)
        {
            // 버전 정보 출력
            printf("version: %s\n", szVer);
            break; // 성공 시 루프 탈출
        }   
        // 초기화 오류 메시지 출력
        printf("%s init error\n", device_path);
    } while(true); // 성공할 때까지 계속 시도

    return hdev; // 장치 핸들 반환
}

// 카드를 감지하는 함수
int detectCards(int hdev)
{
    unsigned char   prevSNR[17];    // 이전 카드 시리얼 번호 저장 배열
    unsigned char   snr[17];        // 현재 카드 시리얼 번호 저장 배열
    unsigned char   snSize;         // 시리얼 번호 크기
    unsigned char   sak;            // SAK (Select Acknowledge) 값
    unsigned int    tag;            // 태그 타입

    bool noCardmsg = true; // "카드 없음" 메시지 출력 여부 플래그
    memset(prevSNR, 0, sizeof(prevSNR)); // 이전 SNR 배열 초기화
    printf("Auto detect cards test\n"); // 자동 카드 감지 테스트 시작 메시지

    while (1) // 무한 루프
    {
        lc_rfReset(hdev, 10); // RF 모듈 리셋
        // 카드 폴링 (타입 1 카드, snr, snSize, tag, sak 정보 가져오기)
        if (lc_card(hdev, 1, snr, &snSize, &tag, &sak))
        {
            // 카드가 감지되지 않았고, 이전에 "카드 없음" 메시지를 출력하지 않았다면
            if (noCardmsg)
            {
                memcpy(prevSNR, snr, snSize); // 현재 (빈) SNR을 이전 SNR로 복사
                printf("No card detected\n"); // "카드 없음" 메시지 출력
                noCardmsg = false; // 메시지 출력 플래그를 false로 설정
            }
           continue; // 루프의 처음으로 돌아감
        }
        
        // 이전에 감지된 카드와 다른 카드가 감지된 경우
        if (strncmp((const char*)snr, (const char*)prevSNR, snSize) != 0)
        {
            memcpy(prevSNR, snr, snSize); // 현재 SNR을 이전 SNR로 업데이트
            noCardmsg = true; // "카드 없음" 메시지를 다시 출력할 수 있도록 플래그 설정
            printf("Card detected: SNR="); // 카드 감지 메시지 출력
            for (int i = 0; i < snSize; i++)
            {
                printf("%02X ", snr[i]); // 카드 시리얼 번호(SNR) 출력
            }
            printf(" Tag=%08X SAK=%02X\n", tag, sak); // 태그 타입과 SAK 값 출력
        }
    }
    return 0; // (실제로는 도달하지 않음)
}

// LED 테스트 함수
void test_led(int hdev)
{
    lc_led(hdev, 1, 0); // LED 1 끄기
    lc_led(hdev, 2, 1); // LED 2 켜기
    sleep(1);           // 1초 대기
    lc_led(hdev, 2, 0); // LED 2 끄기
    lc_led(hdev, 1, 1); // LED 1 켜기
    sleep(1);           // 1초 대기
}