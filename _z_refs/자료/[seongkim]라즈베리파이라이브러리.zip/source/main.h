

#ifndef MAIN_H
# define MAIN_H

# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <stdbool.h>
# include <string.h>

# include "comPro.h"

# define BAUDRATE 115200

// rfid.c
int usbRFIDreader_init();
int detectCards(int hdev);
int test_led(int hdev);



#endif /* MAIN_H */